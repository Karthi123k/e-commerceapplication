<?php
	include 'includes/session.php';
	$conn = $pdo->open();
$total =$_GET['total'];

$id = $_SESSION['user'];

$stmt = $conn->prepare("SELECT * FROM cart LEFT JOIN products ON products.id=cart.product_id WHERE user_id=:user_id");
$stmt->execute(['user_id'=>$user['id']]);
$row =$stmt->fetch();
$pincode = $row['pincode'];
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
    $stmt->execute(['id' => $user['id']]);
    
    // Retrieve the email data
    $email = '';
	$address = '';	
	$firstname = '';
	$lastname = '';
	$contact_info= '';	
    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
		$email = $row['email'];
		$address = $row['address'];
		$firstname = $row['firstname'];
		$lastname = $row['lastname'];		
        $contact_info = $row['contact_info'];
    }
    
    // Print the email data
    //echo "Email: " . $email."<br>";
	//echo "address: " . $address."<br>";
	//echo "firstname: " . $firstname." ".$lastname."<br>";	
    //echo "contact_info: " . $contact_info;
} catch (PDOException $e) {
    // Handle any errors that occur during the database query
    echo "Error: " . $e->getMessage();
}





	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Check Out Page</title>
<meta name="GENERATOR" content="Evrsoft First Page">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<h1>Check Out Page</h1>
	<pre>
	</pre>
	<!--
	<form method="post" action="pgRedirect.php">
		<table border="1">
			<tbody>
				<tr>
					<th>S.No</th>
					<th>Label</th>
					<th>Value</th>
				</tr>
				<tr>
					<td>1</td>
					<td><label>ORDER_ID::*</label></td>
					<td><input id="ORDER_ID" tabindex="1" maxlength="20" size="20"
						name="ORDER_ID" autocomplete="off"
						value="<?php //echo  "ORDS" . rand(10000,99999999)?>"readonly>
					</td>
				</tr>
				<tr>
					<td>2</td>
					<td><label>CUSTID ::*</label></td>
					<td><input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="<?php echo $id?>"></td>
				</tr>
				
				<tr>
					<td>5</td>
					<td><label>txnAmount*</label></td>
					<td><input title="TXN_AMOUNT" tabindex="10"
						type="text" name="TXN_AMOUNT"
						value="<?php// echo $total?>"
					</td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td><input value="CheckOut" type="submit"	onclick=""></td>
				</tr>
			</tbody>
		</table>
	
	</form>
	-->

<form class="form-horizontal"  method ="post" action="nonepage.php"> <!--action="pgRedirect.php"-->
<h3>Order Details</h3>
  <div class="form-group">
    <label class="control-label col-sm-2" for="od">Order Id:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="ORDER_ID" id="ORDER_ID" value="<?php echo  "ORDS" . rand(10000,99999999)?>"readonly>
    </div>
  </div>
   <div class="form-group">
    <div class="col-sm-10">
      <input type="hidden" class="form-control" id="CUST_ID"name="CUST_ID" value="<?php echo $id?>"  readonly>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="txtamt">Total Amount(&#8377;):</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="TXN_AMOUNT" value="<?php echo $total?>" name="TXN_AMOUNT" readonly>
    </div>
	</div>
	<?php 
	if($total >0)
	{
		?>
	<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default" name="submit">Checkout</button>
    </div>
  </div> 
  <?php 
	}
	else
	{
		
	?>
	<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
     <p style="color:red"> You Total Amount is Zero. So you can go to back the Products list and add to the cart.</p> 
    </div>
  </div> 
  <?php
	}
	?>
<form>
<h3> Personal Details</h3>
  <div class="form-group">
    <label class="control-label col-sm-2" for="email">Email:</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="email" value="<?php echo $email ?>" name="email" readonly>
    </div>
  </div>
   <div class="form-group">
    <label class="control-label col-sm-2" for="name">Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="name" value="<?php echo $firstname." ".$lastname ?>" name="name" readonly>
    </div>
  </div> <div class="form-group">
    <label class="control-label col-sm-2" for="pincode">Delivery Address Pincode:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="pincode" value="<?php echo $pincode ?>" name="pincode" readonly>
    </div>
	</div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="address">Delivery Address:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="adress" value="<?php echo $address ?>" name="address">
    </div>
	</div>
	
	 <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Mobile Number:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="phone" value="<?php echo $contact_info ?>" name="phone">
    </div>
  </div><div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
   <!--   <button type="submit" class="btn btn-default" name="submit">Checkout</button>-->
    </div>
  </div>

  </form>
 

</body>
</html>
<!--<script>
  document.getElementById('form-horizontal').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting normally

    // Retrieve the form data
    const input1Value = document.getElementById('ORDER_ID').value;
    const input2Value = document.getElementById('CUST_ID').value;
     const input3Value = document.getElementById('TXN_AMOUNT').value;
    // Send the form data to the first destination
    sendData('pgRedirect.php', { ORDER_ID: input1Value, CUST_ID: input2Value,TXN_AMOUNT:input3Value  });

    /*Send the form data to the second destination
    sendData('page2.php', { input1: input1Value, input2: input2Value });
*/
    // You can add more destinations if needed

  
  });

  // Function to send form data using AJAX
  function sendData(url, data) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(data));
  }
</script>-->