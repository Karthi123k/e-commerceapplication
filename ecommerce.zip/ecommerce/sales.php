<?php
	include 'includes/session.php';

	if(isset($_POST['submit'])){
		 $payid = $_POST['pay'];
		$date = date('Y-m-d');
		$o_id =$_POST['o_id'];
		$u_id =$_POST['u_id'];
		$total =$_POST['total'];
		$email =$_POST['email'];
		$name =$_POST['name'];
		$d_pincode =$_POST['d_pincode'];
		$d_address =$_POST['d_address'];
		$d_mobile =$_POST['d_mobile'];
		$d_status=$_POST['d_status'];


		$conn = $pdo->open();

		try{
			
			$stmt = $conn->prepare("INSERT INTO sales (user_id, pay_id, sales_date) VALUES (:user_id, :pay_id, :sales_date)");
			$stmt->execute(['user_id'=>$user['id'], 'pay_id'=>$payid, 'sales_date'=>$date]);
			$salesid = $conn->lastInsertId();
			
			try{
				$stmt = $conn->prepare("SELECT * FROM cart LEFT JOIN products ON products.id=cart.product_id WHERE user_id=:user_id");
				$stmt->execute(['user_id'=>$user['id']]);

				foreach($stmt as $row){
					$stmt = $conn->prepare("INSERT INTO details (sales_id, product_id, quantity) VALUES (:sales_id, :product_id, :quantity)");
					$stmt->execute(['sales_id'=>$salesid, 'product_id'=>$row['product_id'], 'quantity'=>$row['quantity']]);
				}

				$stmt = $conn->prepare("DELETE FROM cart WHERE user_id=:user_id");
				$stmt->execute(['user_id'=>$user['id']]);
				// code stock update after purchase
				$stmt = $conn->prepare("select  * FROM products WHERE id=:id");
				$stmt->execute(['id'=>$row['product_id']]);
				$row1 =$stmt->fetch();
               $stock= $row1['stock'];
				$stock= $stock-$row['quantity'];
				$stmt = $conn->prepare("UPDATE products SET stock =:stock WHERE id =:id");
				$stmt->execute(['stock'=>$stock, 'id'=>$row['product_id']]);
				
			    //order_deatils query
				$stmt = $conn->prepare("INSERT INTO order_details (sales_id, user_id, u_name, o_addres, o_number, o_email, ordered_id, o_total, o_pincode, o_date, d_status) VALUES (:sales_id, :user_id, :u_name, :o_addres, :o_number,:o_email, :ordered_id, :o_total,:o_pincode,:o_date,:d_status)");
					$stmt->execute(['sales_id'=> $salesid ,'user_id'=>$u_id, 'u_name'=>$name, 'o_addres'=>$d_address,'o_number'=>$d_mobile, 'o_email'=>$email, 'ordered_id'=>$o_id,'o_total'=>$total ,'o_pincode'=>$d_pincode,'o_date'=>$date,'d_status'=>$d_status]);
				
				
				$_SESSION['success'] = 'Transaction successful. Thank you.';

			}
			catch(PDOException $e){
				$_SESSION['error'] = $e->getMessage();
			}

		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	
header('location: profile.php');
	
?>