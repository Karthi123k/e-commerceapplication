<?php
	include 'includes/session.php';

	if(isset($_POST['submit'])){
		$otp = $_POST['otp'];
		
		$conn = $pdo->open();

		try{
			$stmt = $conn->prepare("select * from order_details where d_otp= :d_otp");
			$stmt->execute(['d_otp'=>$otp]);
              $row=$stmt->fetch();
			  $OrderId = $row['ordered_id'];
			$_SESSION['success'] =  $OrderId."This order placed Successfull";
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	header('location: sales.php');
	
?>