<?php
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
require_once '../PHPMailer/src/PHPMailer.php';
require_once '../PHPMailer/src/SMTP.php';
require_once '../PHPMailer/src/Exception.php';
include 'includes/session.php';

   $conn = $pdo->open();
		if(isset($_POST['otp'])){
         $id = $_GET['id'];;
	    $stmt = $conn->prepare("SELECT * FROM order_details where sales_id=:sales_id");
		$stmt->execute(['sales_id'=>$id]);
        $row=$stmt->fetch();
         $email=$row['o_email'];
        $otp = random_int(100000, 999999);
         $date = date('Y-m-d');
         $d_status ="Completed";


				try{
					$stmt = $conn->prepare("update order_details set d_status=:d_status,d_otp=:d_otp,d_date=:d_date WHERE o_email=:o_email ");
			      	$stmt->execute(['d_status'=>$d_status, 'd_otp'=>$otp, 'd_date'=>$date, 'o_email'=>$email]);
			  	    $userid = $conn->lastInsertId();

					$message = "
						<h2>Thank you for Shopping.</h2>
						<p>Your Account:</p>
						<p>Email: ".$email."</p>						
						<p>Your Order Otp Is :".$otp."</p>
						
					";

					//Load phpmailer
		    		require '../vendor/autoload.php';

		    		$mail = new PHPMailer(true);                             
				    try {
				        //Server settings
				        $mail->isSMTP();                                     
				        $mail->Host = 'smtp.gmail.com';                      
				        $mail->SMTPAuth = true;                               
				        $mail->Username = 'thurbilli@gdctuni.edu.in';     
				        $mail->Password = 'aqwlxwmidgdyuzfu';                    
				        $mail->SMTPOptions = array(
				            'ssl' => array(
				            'verify_peer' => false,
				            'verify_peer_name' => false,
				            'allow_self_signed' => true
				            )
				        );                         
				        $mail->SMTPSecure = 'ssl';                           
				        $mail->Port = 465;                                   

				        $mail->setFrom('thurbilli@gdctuni.edu.in');
				        
				        //Recipients
				        $mail->addAddress($email);              
				        $mail->addReplyTo('thurbilli@gdctuni.edu.in');
				       
				        //Content
				        $mail->isHTML(true);                                  
				        $mail->Subject = 'Your Order Otp';
				        $mail->Body    = $message;

				        $mail->send();
					}
					catch (Exception $e) {
				        $_SESSION['error'] = 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo;
				       // header('location: sales.php');
				    }


				}
				catch(PDOException $e){
					$_SESSION['error'] = $e->getMessage();
//header('location: sales.php');
				}
				$pdo->close();
?>
	


<div class="modal fade" id="otp">
    <div class="modal-dialog">
        <div class="modal-content">
           
            <div class="modal-body">
           


<form class="form-horizontal" method="POST" action="otp_send.php">
                <div class="text-center">
                    <p>Enter The Otp</p>
                    <h2 class="bold fullname"></h2>
					<input type="text" class="otp" name="otp">
					<input type="submit" name="submit">
					
                </div>
            </div> 
		<p> otp sent to this  <?php echo $email; }?>
            <div class="modal-footer">
              <!--<button type="submit" class="btn btn-success btn-flat" name="otp_submit"><i class="fa fa-check"></i> Submit</button>-->
              </form>
            </div>
        </div>
    </div>
</div>
