
<?php if(isset($_POST['signup'])){
	echo'hello karthik';
}
	?>