
<?php

	include 'includes/session.php';

	$conn = $pdo->open();

	$output = array('error'=>false);

	$id = $_POST['id'];
	$qty = $_POST['qty'];
    $stmt = $conn->prepare("SELECT * FROM  products WHERE id=:id");
	$stmt->execute([ 'id'=>$id]);
	$row1 = $stmt->fetch();
 
	if(isset($_SESSION['user'])){
		try{
			$stmt = $conn->prepare("UPDATE cart SET quantity=:quantity WHERE id=:id");
			$stmt->execute(['quantity'=>$qty, 'id'=>$id]);
			$output['message'] = 'Updated';
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}
	}
	else{
		foreach($_SESSION['cart'] as $key => $row){
			if($row['productid'] == $id){
				$_SESSION['cart'][$key]['quantity'] = $qty;
				$output['message'] = 'Updated';
			}
		}
	}
 

 
	$pdo->close();
	echo json_encode($output);
	
	?>
	<?php
	/*
session_start();

include 'includes/session.php';
echo("<meta http-equiv='refresh'>"); 
$conn = $pdo->open();

$output = array('error' => false);

$id = $_POST['id'];
$qty = $_POST['qty'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id=:id");
$stmt->execute(['id' => $id]);
$row = $stmt->fetch();

if ($row) {
    $stock = $row['stock'];

    // Validate against product stock
    if ($qty <= $stock) {
        if (isset($_SESSION['user'])) {
            try {
                $stmt = $conn->prepare("UPDATE cart SET quantity=:quantity WHERE id=:id");
                $stmt->execute(['quantity' => $qty, 'id' => $id]);
                $output['message'] = 'Updated';
            } catch (PDOException $e) {
                $output['error'] = true;
                $output['message'] = $e->getMessage();
            }
        } else {
            // Validate against cart quantity
            foreach ($_SESSION['cart'] as $key => $cartItem) {
                if ($cartItem['productid'] == $id) {
                    // Calculate the new total quantity in the cart
                    $cartQty = $qty - $cartItem['quantity'];
                    $totalQty = 0;
                    foreach ($_SESSION['cart'] as $item) {
                        if ($item['productid'] != $id) {
                            $totalQty += $item['quantity'];
                        }
                    }

                    // Check if the new cart quantity exceeds the product stock
                    if (($totalQty + $cartQty) <= $stock) {
                        $_SESSION['cart'][$key]['quantity'] = $qty;
                        $output['message'] = 'Updated';
                    } else {
                        $output['error'] = true;
                        $output['message'] = 'Requested quantity exceeds available stock or cart quantity.';
                    }
                    break;
                }
            }
        }
    } else {
        $output['error'] = true;
        $output['message'] = 'Requested quantity exceeds available stock.';
		$_SESSION['success'] = 'Requested quantity exceeds available stock.';
		
    }
} else {
    $output['error'] = true;
    $output['message'] = 'Product not found.';
}

$pdo->close();
echo json_encode($output);*/
?>


