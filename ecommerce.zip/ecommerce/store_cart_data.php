<?php
session_start(); // Start the session

if (isset($_POST['cartData'])) {
  $data = $_POST['cartData'];
  $_SESSION['cartData'] = $data;
 
}
?>
