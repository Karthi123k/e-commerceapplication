<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyrights &copy;  <a href="#">Thurbilli Karthik</a> </strong>
    </div>
</footer>