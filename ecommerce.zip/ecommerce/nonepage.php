<?php
$o_id =$_POST['ORDER_ID'];
$u_id =$_POST['CUST_ID'];
$total =$_POST['TXN_AMOUNT'];
$email =$_POST['email'];
$name =$_POST['name'];
$d_pincode =$_POST['pincode'];
$d_address =$_POST['address'];
$d_mobile =$_POST['phone'];
$d_status="Processing";





 if(isset($_POST['submit']))
 {
	 ?>
<div style="text-align:center;">
<img src="./images/please-wait.gif" style="border-radius:50%; height:400px;">
<p style="font-size:30px;color:red"> Your Transaction is under process. Don't close the window.</p></div>

<?php  
$payid = "Payment" . rand(1,99999999);

/*
if (is_numeric($payid)) {
    // Perform any necessary operations here

    // Redirect to another page after submission
    header('Location: sales.php?pay='+$payid);
   
}
*/
 }
 ?>
 <form action="sales.php" method="post">
  <input type="hidden" value="<?php echo $o_id?>" name="o_id">
 <input type="hidden" value="<?php echo $u_id?>" name="u_id">
 <input type="hidden" value="<?php echo $total?>" name="total">
 <input type="hidden" value="<?php echo $email?>" name="email">
 <input type="hidden" value="<?php echo $name?>" name="name">
 <input type="hidden" value="<?php echo $d_pincode?>" name="d_pincode">
 <input type="hidden" value="<?php echo $d_address?>" name="d_address">
 <input type="hidden" value="<?php echo $d_mobile?>" name="d_mobile">
 <input type="hidden" value="<?php echo $d_status?>" name="d_status">

 <input type="hidden" value="<?php echo$payid?>" name="pay">
 <input type="submit" name="submit">
 </form>